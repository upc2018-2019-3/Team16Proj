﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class 一键接单 : Form
    {
        public 一键接单()
        {
            InitializeComponent();
        }

        private void 一键接单_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet2.订单”中。您可以根据需要移动或删除它。
            this.订单TableAdapter1.Fill(this.dataSet2.订单);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count == 0)//判断是否选中某行
            {
                MessageBox.Show("请先选择一行数据");
                return;
            }
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("司机不能为空");
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("订单号不能为空");
                return;
            }

            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(@"database=DaChe;server=.;Integrated Security=True");
            conn.Open();
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("UPDATE 订单 SET 司机= '" + textBox1.Text + "' WHERE 订单号=" + textBox2.Text, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("操作成功");
            conn.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowindex = e.RowIndex;
            try
            {
                //获得当前行的第一列的值
                textBox2.Text = dataGridView1.Rows[rowindex].Cells[2].Value.ToString();
            }
            catch (Exception exc) { MessageBox.Show(exc.Message); }
        }
    }
}
