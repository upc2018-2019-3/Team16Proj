﻿namespace DaCheSystem
{
    partial class 支付
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.dataSet2 = new DaCheSystem.DataSet2();
            this.订单BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.订单TableAdapter = new DaCheSystem.DataSet2TableAdapters.订单TableAdapter();
            this.出发地DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.目的地DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.订单号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.订单BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.出发地DataGridViewTextBoxColumn,
            this.目的地DataGridViewTextBoxColumn,
            this.订单号DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.订单BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(18, 87);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(764, 330);
            this.dataGridView1.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(68, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "支付";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataSet2
            // 
            this.dataSet2.DataSetName = "DataSet2";
            this.dataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 订单BindingSource
            // 
            this.订单BindingSource.DataMember = "订单";
            this.订单BindingSource.DataSource = this.dataSet2;
            // 
            // 订单TableAdapter
            // 
            this.订单TableAdapter.ClearBeforeFill = true;
            // 
            // 出发地DataGridViewTextBoxColumn
            // 
            this.出发地DataGridViewTextBoxColumn.DataPropertyName = "出发地";
            this.出发地DataGridViewTextBoxColumn.HeaderText = "出发地";
            this.出发地DataGridViewTextBoxColumn.Name = "出发地DataGridViewTextBoxColumn";
            this.出发地DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 目的地DataGridViewTextBoxColumn
            // 
            this.目的地DataGridViewTextBoxColumn.DataPropertyName = "目的地";
            this.目的地DataGridViewTextBoxColumn.HeaderText = "目的地";
            this.目的地DataGridViewTextBoxColumn.Name = "目的地DataGridViewTextBoxColumn";
            this.目的地DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 订单号DataGridViewTextBoxColumn
            // 
            this.订单号DataGridViewTextBoxColumn.DataPropertyName = "订单号";
            this.订单号DataGridViewTextBoxColumn.HeaderText = "订单号";
            this.订单号DataGridViewTextBoxColumn.Name = "订单号DataGridViewTextBoxColumn";
            this.订单号DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 支付
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Name = "支付";
            this.Text = "支付";
            this.Load += new System.EventHandler(this.支付_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.订单BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private DataSet2 dataSet2;
        private System.Windows.Forms.BindingSource 订单BindingSource;
        private DataSet2TableAdapters.订单TableAdapter 订单TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出发地DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 目的地DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 订单号DataGridViewTextBoxColumn;
    }
}