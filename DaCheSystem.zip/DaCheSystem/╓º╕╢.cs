﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class 支付 : Form
    {
        public 支付()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("支付成功！");
        }

        private void 支付_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet2.订单”中。您可以根据需要移动或删除它。
            this.订单TableAdapter.Fill(this.dataSet2.订单);

        }
    }
}
