﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class 用户评价 : Form
    {
        public 用户评价()
        {
            InitializeComponent();
        }

        private void 用户评价_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet1.订单”中。您可以根据需要移动或删除它。
            this.订单TableAdapter.Fill(this.dataSet1.订单);
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = comboBox1.Text;// 订单
            string b = comboBox2.Text;// 等级
            string c = textBox1.Text;// 评价内容
            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(@"database=DaChe;server=.;Integrated Security=True");
            conn.Open();
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("UPDATE 订单 SET 等级= '" + b + "',评价= '" + c + "' WHERE 订单号=" + a, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("操作成功");
            conn.Close();
        }
    }
}
