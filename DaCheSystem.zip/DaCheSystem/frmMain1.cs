﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class frmMain1 : Form
    {
        public frmMain1()
        {
            InitializeComponent();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 新增管理员ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 新增管理员();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 删改管理员ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 删改管理员();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 管理员列表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 查询管理员();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 新增用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 新增用户();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 删改用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 删改用户();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 用户列表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 用户列表();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 新增司机ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 新增司机();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 删改司机ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 删改司机();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 司机列表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 司机列表();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 订单列表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 订单列表();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 一键打车ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 一键打车();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 司机接单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 一键接单();
            fr.MdiParent = this;
            fr.Show();
        }

        private void 支付ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 支付();
            fr.MdiParent = this;
            fr.Show();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
        }

        private void 订单评价ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new 用户评价();
            fr.MdiParent = this;
            fr.Show();
        }
    }
}
