﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class 删改用户 : Form
    {
        public 删改用户()
        {
            InitializeComponent();
        }

        private void 删改用户_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet1.用户”中。您可以根据需要移动或删除它。
            this.用户TableAdapter.Fill(this.dataSet1.用户);
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(@"database=DaChe;server=.;Integrated Security=True");
            conn.Open();
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("UPDATE 用户 SET 用户名= '" + textBox2.Text + "',密码= '" + textBox3.Text + "',姓名= '" + textBox4.Text + "',电话= '" + textBox5.Text + "' WHERE 编号=" + textBox1.Text, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("操作成功");
            conn.Close();
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(@"database=DaChe;server=.;Integrated Security=True");
            conn.Open();
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("DELETE 用户  WHERE 编号=" + textBox1.Text, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("操作成功");
            conn.Close();
        }
    }
}
