﻿namespace DaCheSystem
{
    partial class 一键接单
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.订单TableAdapter = new DaCheSystem.DataSet1TableAdapters.订单TableAdapter();
            this.出发地DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.目的地DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.订单号DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.订单BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet2 = new DaCheSystem.DataSet2();
            this.订单TableAdapter1 = new DaCheSystem.DataSet2TableAdapters.订单TableAdapter();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.订单BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(530, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "接单";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.出发地DataGridViewTextBoxColumn,
            this.目的地DataGridViewTextBoxColumn,
            this.订单号DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.订单BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(18, 86);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(764, 330);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // 订单TableAdapter
            // 
            this.订单TableAdapter.ClearBeforeFill = true;
            // 
            // 出发地DataGridViewTextBoxColumn
            // 
            this.出发地DataGridViewTextBoxColumn.DataPropertyName = "出发地";
            this.出发地DataGridViewTextBoxColumn.HeaderText = "出发地";
            this.出发地DataGridViewTextBoxColumn.Name = "出发地DataGridViewTextBoxColumn";
            this.出发地DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 目的地DataGridViewTextBoxColumn
            // 
            this.目的地DataGridViewTextBoxColumn.DataPropertyName = "目的地";
            this.目的地DataGridViewTextBoxColumn.HeaderText = "目的地";
            this.目的地DataGridViewTextBoxColumn.Name = "目的地DataGridViewTextBoxColumn";
            this.目的地DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 订单号DataGridViewTextBoxColumn
            // 
            this.订单号DataGridViewTextBoxColumn.DataPropertyName = "订单号";
            this.订单号DataGridViewTextBoxColumn.HeaderText = "订单号";
            this.订单号DataGridViewTextBoxColumn.Name = "订单号DataGridViewTextBoxColumn";
            this.订单号DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // 订单BindingSource
            // 
            this.订单BindingSource.DataMember = "订单";
            this.订单BindingSource.DataSource = this.dataSet2;
            // 
            // dataSet2
            // 
            this.dataSet2.DataSetName = "DataSet2";
            this.dataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 订单TableAdapter1
            // 
            this.订单TableAdapter1.ClearBeforeFill = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(352, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(138, 21);
            this.textBox1.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(292, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "司机：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "订单号：";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(79, 33);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(138, 21);
            this.textBox2.TabIndex = 14;
            // 
            // 一键接单
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "一键接单";
            this.Text = "一键接单";
            this.Load += new System.EventHandler(this.一键接单_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.订单BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource 订单BindingSource;
        private DataSet1TableAdapters.订单TableAdapter 订单TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出发地DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 目的地DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 订单号DataGridViewTextBoxColumn;
        private DataSet2 dataSet2;
        private DataSet2TableAdapters.订单TableAdapter 订单TableAdapter1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
    }
}