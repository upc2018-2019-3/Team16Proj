﻿namespace DaCheSystem {
    
    
    public partial class DataSet1 {
    }
}
