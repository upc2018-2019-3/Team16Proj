﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class 新增用户 : Form
    {
        public 新增用户()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(@"database=DaChe;server=.;Integrated Security=True");
            conn.Open();
            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO 用户 (用户名 ,密码 ,姓名 ,电话 ) VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("操作成功");
            conn.Close();
        }

        private void 新增用户_Load(object sender, EventArgs e)
        {
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
        }
    }
}
