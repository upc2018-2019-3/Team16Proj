﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
            comboBox1.Text = "管理员";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text.Trim();
            string userPwd = textBox2.Text.Trim();
            string userRole = comboBox1.Text;

            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(userPwd))
            {
                MessageBox.Show("用户名或密码不能为空！");
                return;
            }
            if(string.IsNullOrEmpty(userRole))
            {
                MessageBox.Show("角色不能为空！");
                return;
            }

            if (userRole == "管理员")
            {
                MessageBox.Show("恭喜您登录成功！");
                this.Hide();
                var fr = new frmMain();
                fr.ShowDialog();                
                return;
            }
            else if (userRole == "司机")
            {
                MessageBox.Show("恭喜您登录成功！");
                this.Hide();
                var fr = new frmMain2();
                fr.ShowDialog();
                return;
            }
            else if (userRole == "用户")
            {
                MessageBox.Show("恭喜您登录成功！");
                this.Hide();
                var fr = new frmMain1();
                fr.ShowDialog();
                return;
            }

        }
    }
}
