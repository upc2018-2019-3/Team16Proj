﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DaCheSystem
{
    public partial class 司机列表 : Form
    {
        public 司机列表()
        {
            InitializeComponent();
        }

        private void 司机列表_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet1.司机”中。您可以根据需要移动或删除它。
            this.司机TableAdapter.Fill(this.dataSet1.司机);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var conn = new System.Data.SqlClient.SqlConnection("database=DaChe;server=.;Integrated Security=True");
            conn.Open();
            string strWhere = string.Empty;
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                strWhere += string.Format(" AND 用户名 LIKE '{0}%' ", textBox1.Text);
            }
            var da = new System.Data.SqlClient.SqlDataAdapter("select * from 司机 where 1=1 " + strWhere, conn);
            var dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
