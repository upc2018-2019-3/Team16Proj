﻿namespace DaCheSystem
{
    partial class frmMain1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用户列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.订单管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.订单列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一键打车ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.支付ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.订单评价ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.用户ToolStripMenuItem,
            this.订单管理ToolStripMenuItem,
            this.系统管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(746, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 用户ToolStripMenuItem
            // 
            this.用户ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.用户列表ToolStripMenuItem});
            this.用户ToolStripMenuItem.Name = "用户ToolStripMenuItem";
            this.用户ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.用户ToolStripMenuItem.Text = "用户信息";
            // 
            // 用户列表ToolStripMenuItem
            // 
            this.用户列表ToolStripMenuItem.Name = "用户列表ToolStripMenuItem";
            this.用户列表ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.用户列表ToolStripMenuItem.Text = "用户列表";
            this.用户列表ToolStripMenuItem.Click += new System.EventHandler(this.用户列表ToolStripMenuItem_Click);
            // 
            // 订单管理ToolStripMenuItem
            // 
            this.订单管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.订单列表ToolStripMenuItem,
            this.一键打车ToolStripMenuItem,
            this.支付ToolStripMenuItem,
            this.订单评价ToolStripMenuItem});
            this.订单管理ToolStripMenuItem.Name = "订单管理ToolStripMenuItem";
            this.订单管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.订单管理ToolStripMenuItem.Text = "订单管理";
            // 
            // 订单列表ToolStripMenuItem
            // 
            this.订单列表ToolStripMenuItem.Name = "订单列表ToolStripMenuItem";
            this.订单列表ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.订单列表ToolStripMenuItem.Text = "订单列表";
            this.订单列表ToolStripMenuItem.Click += new System.EventHandler(this.订单列表ToolStripMenuItem_Click);
            // 
            // 一键打车ToolStripMenuItem
            // 
            this.一键打车ToolStripMenuItem.Name = "一键打车ToolStripMenuItem";
            this.一键打车ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.一键打车ToolStripMenuItem.Text = "一键打车";
            this.一键打车ToolStripMenuItem.Click += new System.EventHandler(this.一键打车ToolStripMenuItem_Click);
            // 
            // 支付ToolStripMenuItem
            // 
            this.支付ToolStripMenuItem.Name = "支付ToolStripMenuItem";
            this.支付ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.支付ToolStripMenuItem.Text = "支付";
            this.支付ToolStripMenuItem.Click += new System.EventHandler(this.支付ToolStripMenuItem_Click);
            // 
            // 系统管理ToolStripMenuItem
            // 
            this.系统管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem});
            this.系统管理ToolStripMenuItem.Name = "系统管理ToolStripMenuItem";
            this.系统管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.系统管理ToolStripMenuItem.Text = "系统管理";
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 订单评价ToolStripMenuItem
            // 
            this.订单评价ToolStripMenuItem.Name = "订单评价ToolStripMenuItem";
            this.订单评价ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.订单评价ToolStripMenuItem.Text = "订单评价";
            this.订单评价ToolStripMenuItem.Click += new System.EventHandler(this.订单评价ToolStripMenuItem_Click);
            // 
            // frmMain1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 439);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain1";
            this.Text = "frmMain";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 用户列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 订单管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 订单列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一键打车ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 支付ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 订单评价ToolStripMenuItem;
    }
}